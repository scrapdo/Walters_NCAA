# Walters CBB Analyzer

NCAA basketball betting edge detector built on Billy Walters' system from *Gambler*, powered by KenPom 2026 efficiency ratings.

## Features
- Fetches today's/tomorrow's D1 spreads and over/unders via live search
- Fetches live KenPom AdjO / AdjD / Tempo data
- Calculates power line (spread) and projected total using KenPom formula
- Edge detection with 1–3 star rating system
- AI analysis via Claude (spread + total recommendations)
- Bet log with ATS and O/U outcome tracking

---

## Deploy to Vercel

### 1. Fork or upload to GitHub
Upload this entire folder as a GitHub repository.

### 2. Connect to Vercel
1. Go to [vercel.com](https://vercel.com) and sign in with GitHub
2. Click **Add New Project** → select this repo
3. Vercel auto-detects Vite — just click **Deploy**

### 3. Add your Anthropic API key
1. In Vercel, go to your project → **Settings → Environment Variables**
2. Add a new variable:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your key from [console.anthropic.com](https://console.anthropic.com)
3. Click **Save**, then **Redeploy** from the Deployments tab

Your app will be live at `https://your-project.vercel.app`.

---

## Local development

```bash
npm install
```

Create a `.env.local` file in the project root:
```
ANTHROPIC_API_KEY=sk-ant-...
```

Then run:
```bash
npm run dev
```

The app runs at `http://localhost:5173`. The `/api/claude` proxy function runs automatically via Vite's dev server proxy... actually for local dev, Vercel CLI is easier:

```bash
npm install -g vercel
vercel dev
```

This runs both the React app and the serverless function locally on port 3000.

---

## How the proxy works

The app calls `/api/claude` instead of the Anthropic API directly. The `api/claude.js` serverless function (runs on Vercel's edge) injects your `ANTHROPIC_API_KEY` from environment variables before forwarding to Anthropic. Your key is never exposed to the browser.

---

## Updating KenPom data

The app fetches live AdjO/AdjD/Tempo each time you hit **Fetch Games**. The static rank data in `src/App.jsx` (the `K` array) reflects end-of-2025-26 season rankings — update it each preseason by replacing the array with fresh KenPom rankings.
