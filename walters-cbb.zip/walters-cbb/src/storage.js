// Storage shim: uses Claude's window.storage when available (claude.ai),
// falls back to localStorage for standalone deployment (Vercel etc.)
const storage = window.storage || {
  get: async (key) => {
    const val = localStorage.getItem(key);
    return val ? { key, value: val } : null;
  },
  set: async (key, value) => {
    localStorage.setItem(key, value);
    return { key, value };
  },
  delete: async (key) => {
    localStorage.removeItem(key);
    return { key, deleted: true };
  },
};

export default storage;
